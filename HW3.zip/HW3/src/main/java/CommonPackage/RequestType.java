// Name: Peijing (Penelope) Luo
// Andrew ID: peijingl
// Class: 95712 D
// Purpose: contains the constants of request type

package CommonPackage;

public enum RequestType {
    SEARCH,
    INSERT,
    DELETE,
    QUIT;
}
