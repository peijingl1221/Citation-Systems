// Name: Peijing (Penelope) Luo
// Andrew ID: peijingl
// Class: 95712 D
// Purpose: contains the constants of field type

package CommonPackage;

public enum FieldType {
    NUMBER,
    NAME,
    TYPEOFOFFENSE,
    USERID;
}
